#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int nr=0;
typedef struct info
	{
		int id_paranteza;
		char tip[5];

	}TInfo;


typedef struct celula
	{

		void *info;
		struct celula *urm;
	}TCelula,*TLista,**ALista;

typedef struct stiva
	{
		TLista vf;
	}TStiva;




typedef struct coada
	{
		TLista inceput;
		TLista sfarsit;
	}TCoada;


	

TLista AlocaCelula(TInfo *info)
	{
		TLista aux=malloc(sizeof(TCelula));
		if(!aux) return NULL;
		aux->info=info;
		aux->urm=NULL;
		return aux;
	}

void push_stiva(TStiva *stiva,TLista celula)
	{
		if(stiva->vf==NULL)
		{
			stiva->vf=celula;
		}
		
		else
		{
			celula->urm=stiva->vf;
			stiva->vf=celula;
		}

	}



void push_coada(TCoada *coada,TLista celula)
	{
		if(!coada->inceput)
			coada->inceput=coada->sfarsit=celula;
		else{
			coada->sfarsit->urm=celula;
			coada->sfarsit=celula;
		}


	}

	

void PUSH_STIVA(TStiva **a,FILE *in)
{
	TInfo *aux=malloc(sizeof(TInfo));
	int id_stiva;
	fscanf(in,"%d",&id_stiva);
	fscanf(in,"%d",&aux->id_paranteza);
	fscanf(in,"%s",aux->tip);
	TStiva *stiva=*a;
	TLista celula=AlocaCelula(aux);
	push_stiva(&stiva[id_stiva],celula);
	
	


}

void PUSH_COADA(TCoada **a,FILE *in)
{
	TInfo *aux=malloc(sizeof(TInfo));
	int id_coada;
	fscanf(in,"%d",&id_coada);
	fscanf(in,"%d",&aux->id_paranteza);
	fscanf(in,"%s",aux->tip);
	TCoada *coada=*a;
	TLista celula=AlocaCelula(aux);
	celula->urm=NULL;
	TInfo *m=(TInfo*)(celula->info);
	push_coada(&coada[id_coada],celula);

	
}

void pop_stiva(TStiva *a)
{
	
	
	
	if(!a->vf)
	{
		return ;
	}
	else{
		
		//TLista aux=a->vf;
		a->vf=a->vf->urm;
		//dezalocare_TLista(&aux);
	}

}

void pop_coada(TCoada *coada)
{
	
	
	
	if(!coada->inceput)
	{
		return ;
	}
	else{
		
		//TLista aux=a->vf;
		coada->inceput=coada->inceput->urm;
		//dezalocare_TLista(&aux);
	}
	if(coada->inceput==NULL)
		coada->sfarsit=NULL;

}

void transfer_celula_2_cozi(TCoada *coada_primitoare,TCoada*coada_donatoare)
{

	if(!coada_donatoare||coada_donatoare->inceput==NULL)
		return;
	TLista aux=coada_donatoare->inceput;
	int ok=0;
	if(coada_primitoare->inceput==NULL)
		ok=1;
		pop_coada(coada_donatoare);
		push_coada(coada_primitoare,aux);
		if(ok==1) 
			aux->urm=NULL;



}


void transfer_celula_2_stive(TStiva *stiva_primitoare,TStiva *stiva_donatoare)
{

	if(!stiva_donatoare||stiva_donatoare->vf==NULL)
		return;
	TLista aux=stiva_donatoare->vf;
	
	pop_stiva(stiva_donatoare);
	int ok=0;
	if(stiva_primitoare->vf==NULL)
		ok=1;
	if(ok==1) 	aux->urm=NULL;
	push_stiva(stiva_primitoare,aux);

}

void afisare_stiva(TStiva *stiva,FILE *out)
{
	if(stiva==NULL) return;
	TStiva *a=malloc(sizeof(TStiva));
	a->vf=NULL;
	while(stiva->vf)
	{	
		transfer_celula_2_stive(a,stiva);
	}
	

	fprintf(out,"\"");
	while(a->vf)
	{
		
		
		TInfo *aux=(TInfo*)(a->vf->info);
		if(aux)
		fprintf(out,"%s",aux->tip);
		transfer_celula_2_stive(stiva,a);
		

	}
	fprintf(out,"\"");
		
}	

void afisare_coada(TCoada *coada,FILE *out)
{
	if(coada==NULL) return;
	TCoada *a=malloc(sizeof(TCoada));
	a->inceput=NULL;
	while(coada->inceput)
	{	
		transfer_celula_2_cozi(a,coada);

		

	}

	fprintf(out,"\"");
	while(a->inceput){
		transfer_celula_2_cozi(coada,a);
		TInfo *aux=(TInfo*)(coada->sfarsit->info);
		if(aux)
		fprintf(out,"%s",aux->tip);

	}
	fprintf(out,"\"");
	//free(a)!!!!!!!!!!!!!

	
}

int compara(TLista a,TLista b)
{
	TInfo *a1=(TInfo*)(a->info);
	TInfo *b1=(TInfo*)(b->info);
	return a1->id_paranteza-b1->id_paranteza;
}

void sort_stiva(TStiva *a)
	{
		TStiva *aux=malloc(sizeof(TStiva));
		aux->vf=NULL;

		while(a->vf)
		{	

			TLista celula_curenta=a->vf;
			if(aux->vf==NULL)
			{
				transfer_celula_2_stive(aux,a);
				aux->vf->urm=NULL;
				



			}
			else
			{	pop_stiva(a);
				while( aux->vf && compara(celula_curenta,aux->vf)<0)
				{
					
					
					transfer_celula_2_stive(a,aux);
					
				}

				int ok=0;
				if(aux->vf==NULL) ok=1;
				push_stiva(aux,celula_curenta);
				if(ok==1) celula_curenta->urm=NULL;;
			}

			

		}
		a->vf=aux->vf;

	}
void transfer_din_coada_in_stiva(TCoada *coada,TStiva *stiva)
	{
		stiva->vf=NULL;
		TLista aux;
		
		while(coada->inceput)
		{
			aux=coada->inceput;
			pop_coada(coada);
			if(!stiva||!stiva->vf)
			{
				aux->urm=NULL;
			}
			push_stiva(stiva,aux);
		}

	}

void transfer_din_stiva_in_coada(TCoada *coada,TStiva *stiva)
	{
		//coada->inceput=coada->sfarsit=NULL;
		TLista aux;
		while(stiva->vf)
		{
			int ok=0;
			aux=stiva->vf;
			if(coada->inceput==NULL)
			ok=1;
			pop_stiva(stiva);
			push_coada(coada,aux);
			
			if(ok==1)
				aux->urm=NULL;
			
		}

	}

void sort_coada(TCoada *coada)
	{

		TStiva *stiva=malloc(sizeof(TStiva));
		transfer_din_coada_in_stiva(coada,stiva);
		sort_stiva(stiva);
		TStiva *stiva1=malloc(sizeof(TStiva));
		stiva1->vf=NULL;
		while(stiva->vf)
			transfer_celula_2_stive(stiva1,stiva);
		//afisare_stiva(stiva);
		transfer_din_stiva_in_coada(coada,stiva1);
		//afisare_coada(coada);
		//free(stiva);


	}

int perechi_bune(TCoada *coada,TStiva *stiva)
{	if(!stiva->vf||coada->inceput==NULL) return 0;
	TInfo *a=(TInfo*)(coada->inceput->info);
	TInfo *b=(TInfo*)(stiva->vf->info);
	if(strcmp(a->tip,"(")==0&&strcmp(b->tip,")")==0) return 1;
	if(strcmp(a->tip,"[")==0&&strcmp(b->tip,"]")==0) return 1;
	if(strcmp(a->tip,"{")==0&&strcmp(b->tip,"}")==0) return 1;
	return 0;
}	


int correct_stiva(TStiva stiva)
{	
	if(!stiva->vf) return 0;
	int nr=0,max=0,ok=1,rez1=0,rez2=0;
	TStiva *stiva_aux=malloc(sizeof(TStiva));
	TCoada *coada_aux=malloc(sizeof(TCoada));
	stiva_aux->vf=NULL;
	coada->inceput=coada->sfarsit=NULL;

	while(stiva->vf)
	{
		TInfo *celula_info=(TInfo*)stiva->vf->info;
		while(strstr("([{",celula_info->tip))
		{	rez1=1;
			TLista celula=malloc(sizeof(TCelula));
			celula->info=celula_info;
			celula->urm=NULL;
			push_coada(coada_aux,celula);
			pop_stiva(&stiva);
			if(stiva->vf)
				info=(TInfo*)stiva->vf->info;
			else break;

		}
		nr=0;
		while(stiva_aux->vf &&coada_aux->inceput)
		{
			if(perechi_bune(coada_aux,stiva_aux))
				{	
					pop_stiva(stiva_aux);
					pop_coada(coada_aux);
					max=max+2;
				}
			else 
				{
					ok=0;
					break;
				}	
		}	
		if(ok==0)
			stiva_aux->vf=coada_aux->inceput=coada_aux->sfarsit=NULL;
		else if(coada->inceput)
			coada->inceput=coada->sfarsit=NULL;
		//daca ok==1 atunci a fost imbinare perfecta;
		if(!stiva->vf) return max;
		
		celula_info=(TInfo*)stiva->vf->info
		while(strstr(")]}",info->tip))
		{	rez2=1;
			TLista celula1=malloc(sizeof(TCelula));
			TLista celula1->info=info;
			celula1->urm=NULL;
			push_stiva(stiva_aux,celula1);
			pop_stiva(&stiva);
			if(stiva->vf)
				info=(TInfo*)stiva->vf->info;
			else break;

		}
		if(stiva_aux->vf==NULL||stiva->vf==NULL)
			return max;

		if(rez1==0)
		{	info=(TInfo*)stiva->vf->info;
			while(strstr("([{",celula_info->tip))
			{
			TLista celula=malloc(sizeof(TCelula));
			celula->info=celula_info;
			celula->urm=NULL;
			push_coada(coada_aux,celula);
			pop_stiva(&stiva);
			if(stiva->vf)
				info=(TInfo*)stiva->vf->info;
			else break;
			}
		//CAZ  bun:coada -stiva;
			nr=0;
			while(stiva_aux->vf &&coada_aux->inceput)
			{
			if(perechi_bune(coada_aux,stiva_aux))
				{	
					pop_stiva(stiva_aux);
					pop_coada(coada_aux);
					nr=nr+2;
				}
			else 
				{
					break;
				}	
			}
			if(ok==1)
				if(!stiva_aux&&!coada_aux->inceput)
					max=max+nr;
				else if(max<nr)
					max=nr;

		}





	}
	return max;

}








void afisare_vector_de_stive(TStiva **stiva,int s,FILE *out)
{
	int i=0;
	TStiva *aux=*stiva;
	for(;i<s;i++)
	{	fprintf(out,"\n");
		afisare_stiva(&aux[i],out);

	}
}

void afisare_vector_de_cozi(TCoada **coada,int c,FILE *out)
{
	int i=0;
	TCoada *aux=*coada;
	for(;i<c;i++)
	{	fprintf(out,"\n");
		afisare_coada(&aux[i],out);

	}
}


int main(){

	FILE *in=fopen("test0.in","r");
   	FILE *out=fopen("out.file","w");
	
   
   int n,s,c,i=0,id_stiva,id_coada;
   char operatie[10];
   fscanf(in,"%d %d %d",&n,&s,&c);
   printf("%d %d %d\n",n,s,c);

   TCoada *vector_de_cozi=malloc(c*sizeof(TCoada));
   TStiva *vector_de_stive=malloc(s*sizeof(TStiva));
   for (i=0;i<c;i++)
   {
   	vector_de_cozi[i].inceput=NULL;
   	vector_de_cozi[i].sfarsit=NULL;
   }
   for (i=0;i<s;i++)
   {
   	vector_de_stive[i].vf=NULL;
   }
   //TCoada *vector_de_cozi=malloc(c*sizeof(TCoada));
   //if(vector_de_stive[0].vf==NULL) printf("da");

   for(i=0 ; i < n ; i++)
   {

   	fscanf(in,"%s",operatie);
   	//printf("%s\n",operatie);
   		//if( strcmp(operatie,"intrq") == 0)
   		//{	//printf("hello");
   		//	PUSH_COADA(&vector_de_cozi,in);
   		

   		
   		if(strcmp(operatie,"push") == 0)
   			PUSH_STIVA(&vector_de_stive,in);
   		
   		/*else if( strcmp(operatie,"pop") == 0)
   		{
   			   			
   			fscanf(in,"%d",&id_stiva);
   			pop_stiva(&vector_de_stive[id_stiva]);
   		}
   		
   		/*else if(strcmp(operatie,"extrq") == 0)		//e prost facut!!!!!
   		{
			fscanf(in,"%d",&id_coada);
   			pop_coada(&vector_de_cozi[id_coada]);


   		}*/
   		/*else if(strcmp(operatie,"sorts") == 0)
   		{
   			fscanf(in,"%d",&id_stiva);
   			sort_stiva(&vector_de_stive[id_stiva]);
   		}
   		else if(strcmp(operatie,"sortq") == 0)
   		{
   			fscanf(in,"%d",&id_coada);
   			sort_coada(&vector_de_cozi[id_coada]);
   		}
   		else if(strcmp(operatie,"corrects") == 0)
   		{
   			fscanf(in,"%d",&id_stiva);
   			TStiva *aux=copie_stiva(vector_de_stive[id_stiva]);
   			fprintf(out,"\n");
   			fprintf(out,"%d\n",correct_stiva(aux));
   			//free(aux);
   		}
   		else if(strcmp(operatie,"correctq") == 0)
   		{
   			fscanf(in,"%d",&id_coada);
   			fprintf(out,"\n");
   			fprintf(out,"%d\n",correct_coada(vector_de_cozi[id_coada]));
   			//free(aux);
   		}
   		else if(strcmp(operatie,"prints") == 0)
   		{
   			afisare_vector_de_stive(&vector_de_stive,s,out);
   			

   		}
   		else if(strcmp(operatie,"printq") == 0)
   		{
   			afisare_vector_de_cozi(&vector_de_cozi,c,out);
   		}*/
   		
   		else break;

   }


	
//afisare_coada(&vector_de_cozi[0]);

   TInfo *m=(TInfo*)(vector_de_stive[0].vf->info);




//afisare_stiva(&vector_de_stive[0],out);
printf("%d\n",corect_stiva(vector_de_stive[0]));


}