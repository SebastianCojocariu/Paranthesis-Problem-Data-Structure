#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct info
	{
		int id_paranteza;
		char tip[2];

	}TInfo;

typedef struct info_lungime
	{
		int lungime;

	}TInfoLungime;


typedef struct celula
	{

		void *info;
		struct celula *urm;
	
	}TCelula,*TLista,**ALista;

typedef struct stiva
	{
		TLista vf;
	
	}TStiva;




typedef struct coada
	{
		TLista inceput;
		TLista sfarsit;
	}TCoada;



//Aloca o TLista cu info dat ca parametru(pointerul catre info,defapt)
TLista AlocaCelula(TInfo *info)
	{
		TLista aux =(TLista)malloc(sizeof(TCelula));
		if(!aux) return NULL;
		aux->info = info;
		aux->urm = NULL;
		return aux;
	}
//adauga o TLista in stiva data ca parametru,facand legaturile
void push_stiva(TStiva *stiva , TLista celula)
	{	//stiva nulla
		if(stiva->vf == NULL)
		{
			stiva->vf = celula;
			celula->urm = NULL;
		}
		//stiva nu e nula
		else
		{	
			celula->urm = stiva->vf;
			stiva->vf = celula;
		}

	}


//adauga o TLista in coada data ca parametru,facand legaturile
void push_coada(TCoada *coada , TLista celula)
	{	///coada nula
		if( !coada->inceput)
			coada->inceput = coada->sfarsit = celula;
		else
		//coada nu e nula
		{	
			coada->sfarsit->urm = celula;
			coada->sfarsit = celula;
		}


	}


//functie pe care o apelam atunci cand operatia citita din fisier este push
	//citeste info si aloca o celula avand aceasta informatie
	//adaugand aceasta celula in vectorul de stive(in functie de id_stiva citit)
void PUSH_STIVA(TStiva **a,FILE *in)
	{
		TInfo *aux = (TInfo*)malloc(sizeof(TInfo));
		if(!aux) return;
		int id_stiva;
		fscanf(in ,"%d", &id_stiva);
		fscanf(in ,"%d", &aux->id_paranteza);
		fscanf(in ,"%s", aux->tip);
		TStiva *stiva = *a;
		TLista celula = AlocaCelula(aux);
		push_stiva(&stiva[id_stiva],celula);




	}
//functie pe care o apelam atunci cand operatia citita din fisier este intrq
//citeste info si aloca o celula avand aceasta informatie
//adaugand aceasta celula in vectorul de cozi(in functie de id_coada citit)

void PUSH_COADA(TCoada **a,FILE *in)
	{
		TInfo *aux = (TInfo*)malloc(sizeof(TInfo));
		if(!aux) return;
		int id_coada;
		fscanf(in,"%d",&id_coada);
		fscanf(in,"%d",&aux->id_paranteza);
		fscanf(in,"%s",aux->tip);
		TCoada *coada = *a;
		TLista celula = AlocaCelula(aux);
		celula->urm = NULL;
		push_coada(&coada[id_coada],celula);


	}
//dezaloca celula data ca parametru(pointerul catre celula respectiva)
void dezaloca_celula(TLista a)
{
	if(!a) 
		return;
	else
	{
		TInfo *info=(TInfo*)(a->info);
		free(info);
		
	}
	a = NULL;

}	

//scoate vf-ul stivei,facand legaturile;
void pop_stiva(TStiva *a)
{
		if(!a->vf)
		{
			return ;
		}
		else{

			TLista aux=a->vf;
			a->vf=a->vf->urm;
			//dezaloca_celula(aux);
		}

	}
//scoate inceputul cozii,facand legaturile
void pop_coada(TCoada *coada)
{



	if(!coada->inceput)
	{
		return ;
	}
	else{

		TLista aux=coada->inceput;
		coada->inceput=coada->inceput->urm;
		//dezaloca_celula(aux);
	}
	//preventiv
	if(coada->inceput == NULL)
		coada->sfarsit = NULL;

}
//dezaloca o stiva
void dezaloca_stiva(TStiva *stiva)
{
	if(!stiva)
		return;
	while(stiva->vf)
	{
		TLista aux=stiva->vf;
		pop_stiva(stiva);
		//dezaloca_celula(aux);
	}
	stiva=NULL;

}
//dezaloca o coada
void dezaloca_coada(TCoada *coada)
{
	if(!coada)
		return;
	while(coada->inceput)
	{
		TLista aux = coada->inceput;
		pop_coada(coada);
		//dezaloca_celula(aux);
	}
	coada = NULL;

}
//dezaloca o stiva avand drept info TInfoLungime
void dezaloca_stiva_lungimi(TStiva *stiva)
{
	if(!stiva)
		return;
	while(stiva->vf)
	{
		TLista aux=stiva->vf;
		pop_stiva(stiva);
		TInfoLungime *info_lungime=(TInfoLungime*)(aux->info);
		free(info_lungime);

	}
	stiva=NULL;

}

//transfera Tcelula dintr-o coada intr-o alta coada
void transfer_celula_2_cozi(TCoada *coada_primitoare,TCoada*coada_donatoare)
{

	if(!coada_donatoare||coada_donatoare->inceput==NULL)
		return;
	TLista aux=coada_donatoare->inceput;
	int ok=0;
	if(coada_primitoare->inceput==NULL)
		ok=1;
	
	pop_coada(coada_donatoare);
	push_coada(coada_primitoare,aux);
	
	if(ok==1)
			aux->urm=NULL;



}

//transfera Tcelula dintr-o stiva intr-o alta stiva
void transfer_celula_2_stive(TStiva *stiva_primitoare,TStiva *stiva_donatoare)
{

	if(!stiva_donatoare||stiva_donatoare->vf==NULL)
		return;
	TLista aux=stiva_donatoare->vf;

	pop_stiva(stiva_donatoare);
	int ok=0;
	
	if(stiva_primitoare->vf==NULL)
		ok=1;
	
	if(ok==1) 	aux->urm=NULL;
	
	push_stiva(stiva_primitoare,aux);

}

//afiseaza o stiva in fisierul out
void afisare_stiva(TStiva *stiva,FILE *out)
{
	if(stiva == NULL)
		return;
	TStiva *a = (TStiva*)malloc(sizeof(TStiva));
	a->vf=NULL;
	while(stiva->vf)
	{
		transfer_celula_2_stive(a,stiva);
	}


	fprintf(out,"\"");
	while(a->vf)
	{


		TInfo *aux=(TInfo*)(a->vf->info);
		if(aux)
		fprintf(out,"%s",aux->tip);
		transfer_celula_2_stive(stiva,a);


	}
	//dezaloca_stiva(a);
	fprintf(out,"\"");

}

//afiseaza o coada in fisierul out
void afisare_coada(TCoada *coada,FILE *out)
{
	if(coada==NULL) return;
	TCoada *a=(TCoada*)malloc(sizeof(TCoada));
	a->inceput=NULL;
	while(coada->inceput)
	{
		transfer_celula_2_cozi(a,coada);



	}

	fprintf(out,"\"");
	while(a->inceput)
	{
		transfer_celula_2_cozi(coada,a);
		TInfo *aux=(TInfo*)(coada->sfarsit->info);
		if(aux)
		fprintf(out,"%s",aux->tip);

	}

	fprintf(out,"\"");
	//dezaloca_coada(a);
	//free(a)!!!!!!!!!!!!!


}

//functie de comparatie pentru sorts
int compara(TLista a,TLista b)
{
	TInfo *a1=(TInfo*)(a->info);
	TInfo *b1=(TInfo*)(b->info);
	return a1->id_paranteza-b1->id_paranteza;
}

//sortare stiva
//Sorteaza o stiva data ca parametru dupa algoritmul:
//Se initializeaza o stiva auxiliara.Se extrage rand pe rand varful stivei "mama"(fie el celula_varf).
//Daca stiva_aux e nula se pune celula extrasa
//in stiva_aux.Altfel se compara cu elementele din stiva_aux,pe care le extragem din aceasta si 
//le bagam inapoi in stiva mama pana cand
//celula_varf are id_paranteza >= varful stivei_aux.Se repeta procesul pana cand stiva e goala.Complexitate:O(n^2);

void sort_stiva(TStiva *a)
	{
		TStiva *aux=(TStiva*)malloc(sizeof(TStiva));
		aux->vf=NULL;

		while(a->vf)
		{

			TLista celula_curenta=a->vf;
			if(aux->vf==NULL)
			{
				transfer_celula_2_stive(aux,a);
				aux->vf->urm=NULL;




			}
			else
			{	pop_stiva(a);
				while( aux->vf && compara(celula_curenta,aux->vf)<0)
				{


					transfer_celula_2_stive(a,aux);

				}

				int ok=0;
				if(aux->vf==NULL) ok=1;
				push_stiva(aux,celula_curenta);
				if(ok==1) celula_curenta->urm=NULL;;
			}



		}
		a->vf=aux->vf;

		aux=NULL;


	}

//transfera o coada intr-o stiva
void transfer_din_coada_in_stiva(TCoada *coada,TStiva *stiva)
	{
		stiva->vf=NULL;
		TLista aux;

		while(coada->inceput)
		{
			aux=coada->inceput;
			pop_coada(coada);
			//if(!stiva||!stiva->vf)
			//{
			//	aux->urm=NULL;
			//}
			push_stiva(stiva,aux);
		}
		//dezaloca_coada(coada);

	}

//transfera o stiva intr-o coada
void transfer_din_stiva_in_coada(TCoada *coada,TStiva *stiva)
	{
		//coada->inceput=coada->sfarsit=NULL;
		TLista aux;
		while(stiva->vf)
		{
			int ok=0;
			aux=stiva->vf;
			//if(coada->inceput==NULL)
			//ok=1;
			pop_stiva(stiva);
			push_coada(coada,aux);

			//if(ok==1)
			//	aux->urm=NULL;

		}
		//dezaloca_stiva(stiva);

	}

//sorteaza o coada dupa id_paranteza,apeland functia compara
	//se foloseste sortarea pe stiva astfel:
	//se transfera coada intr-o stiva.Se face sort pe aceasta stiva
	//stiva sortata se transfera intr-o alta stiva1
	//stiva1 se transfera in coada (am facut acest lucru pentru a intra elementele
	//in coada in ordinea corecta
void sort_coada(TCoada *coada)
	{

		TStiva *stiva=(TStiva*)malloc(sizeof(TStiva));
		transfer_din_coada_in_stiva(coada,stiva);
		sort_stiva(stiva);
		TStiva *stiva1=(TStiva*)malloc(sizeof(TStiva));
		stiva1->vf=NULL;
		while(stiva->vf)
			transfer_celula_2_stive(stiva1,stiva);
		//afisare_stiva(stiva);
		transfer_din_stiva_in_coada(coada,stiva1);
		//afisare_coada(coada);
		//free(stiva);

		//dezaloca_stiva(stiva1);
		//dezaloca_stiva(stiva);
	}
//functie care returneaza perechea pentru un tip de paranteza dat
char pereche(char paranteza)
{
    if(paranteza == '(') return ')';
    if(paranteza == ')') return '(';
    if(paranteza == '[') return ']';
    if(paranteza == ']') return '[';
    if(paranteza == '{') return '}';
    if(paranteza == '}') return '{';
}

//functie care calculeaza "drumul parantizat" maximal
//Luam o stiva auxiliara in care inseram parantezele inchise si scoatem parantezele deschise. Astfel putem verifica daca
//parantezele formeaza un drum. Luam inca o stiva in care tinem lungimile drumului format pana acum.
//Cele doua stive sunt sincronizate (cand facem o operatie pe o stiva facem si pe cealalta). Lungimea drumului este comparata 
//la fiecare pas cu lungimea maxima si aceasta este actualizata. Cand ajungem la un caracter care nu poate continua drumul,
//golim stiva auxiliara si cea de lungimi ca sa incepem un nou drum. Cu ajutorul stivei putem sa "rupem" un drum in orice 
//moment daca ajungem la un caracter nepotrivit, ceea ce nu este posibil folosind o variabila simpla.
int corect_stiva(TStiva stiva)
{
    if (!stiva.vf)
        return 0;

    TStiva *stiva_aux=(TStiva*)malloc(sizeof(TStiva));
    stiva_aux->vf=NULL;
	TInfo *info=(TInfo*)(stiva.vf->info), *info_aux;
	TInfoLungime *info_lungime;
	
	int nr=0, maxim=0;
	TStiva *stiva_lungimi=(TStiva*)malloc(sizeof(TStiva));
	stiva_lungimi->vf=NULL;

{
    TLista celula2=(TLista)malloc(sizeof(TCelula));
    celula2->info=(TInfoLungime*)malloc(sizeof(TInfoLungime));
    ((TInfoLungime*)celula2->info)->lungime=0;
    celula2->urm=NULL;
    push_stiva(stiva_lungimi, celula2);

}


	while(stiva.vf)
    {
        if(stiva_aux->vf)
            info_aux=(TInfo*)stiva_aux->vf->info;
        if(stiva_lungimi->vf)
            info_lungime=(TInfoLungime*)stiva_lungimi->vf->info;
        info=(TInfo*)(stiva.vf->info);
        pop_stiva(&stiva);
        if(strstr("([{", info->tip))  
        {
          
            if(stiva_aux->vf)
            {
                
                if(strchr(info->tip,pereche(info_aux->tip[0]))) //perechea buna
                {
                    
                    pop_stiva(stiva_aux);
                    pop_stiva(stiva_lungimi);


                    (((TInfoLungime*)(stiva_lungimi->vf->info))->lungime)+=info_lungime->lungime;
                    if(((TInfoLungime*)stiva_lungimi->vf->info)->lungime>maxim)
                        maxim=((TInfoLungime*)stiva_lungimi->vf->info)->lungime;
                }
                else
                {
                    
                    while(stiva_aux->vf)
                    {

                        pop_stiva(stiva_aux);
                        pop_stiva(stiva_lungimi);
                    }
                    (((TInfoLungime*)(stiva_lungimi->vf->info))->lungime)=0;
                }
            }
            else
            {
                
                (((TInfoLungime*)(stiva_lungimi->vf->info))->lungime)=0;
            }
        }
        else            //paranteza inchisa, inseram in stiva
        {
            
            TLista celula1=(TLista)malloc(sizeof(TCelula));
			celula1->info=info;
			celula1->urm=NULL;
			push_stiva(stiva_aux,celula1);

			info_lungime->lungime += 2;

			TLista celula2=(TLista)malloc(sizeof(TCelula));
			celula2->info=(TInfoLungime*)malloc(sizeof(TInfoLungime));
			((TInfoLungime*)celula2->info)->lungime=0;
			celula2->urm=NULL;
            push_stiva(stiva_lungimi, celula2);
        }
        
    }

   return maxim;
}


//folosim functia corect_stiva,creand pentru fiecare celula din coada o dublura
//pe care o inseram intr-o stiva auxiliara.Functia returneaza corect_stiva(stiva auxiliara);
int corect_coada(TCoada coada)
{

	TStiva *stiva1=(TStiva*)malloc(sizeof(TStiva));
	stiva1->vf=NULL;
	
	while(coada.inceput)
	{
		TInfo *info=(TInfo *)(coada.inceput->info);
		TLista celula=(TLista)malloc(sizeof(TCelula));
		if(!celula) return 0;
		celula->info=info;
		celula->urm=NULL;
		push_stiva(stiva1,celula);
		pop_coada(&coada);
	}
	
	return corect_stiva(*stiva1);
	}

//Afiseaza vectorul de stive in fisierul out
void afisare_vector_de_stive(TStiva **stiva,int s,FILE *out)
{
	int i=0;
	TStiva *aux=*stiva;
	for(; i<s ;i++)
	{	
		afisare_stiva(&aux[i],out);
		fprintf(out,"\n");

	}
}

//Afiseaza vectorul de cozi in fisierul out folosind functiile de afisare stiva/coada
void afisare_vector_de_cozi(TCoada **coada,int c,FILE *out)
{
	int i=0;
	TCoada *aux=*coada;
	for(; i<c; i++)
	{	
		afisare_coada(&aux[i],out);
		fprintf(out,"\n");

	}
}


int main(int argc,char *argv[])
{

	int max=0;
	FILE *in=fopen(argv[1],"r");
   	FILE *out=fopen(argv[2],"w");
   
  
   	
	
   
   int n,s,c,i=0,id_stiva,id_coada;
   char operatie[10];
   fscanf(in,"%d %d %d",&n,&s,&c);

   TCoada *vector_de_cozi=(TCoada*)malloc(c*sizeof(TCoada));
   TStiva *vector_de_stive=(TStiva*)malloc(s*sizeof(TStiva));
   if(!vector_de_stive||!vector_de_cozi)
   	{
   		printf("nu s-a putut aloca unul din cei 2 vectori");
   		return 0;
   	}
   
   for (i=0;i<c;i++)
   {
   	vector_de_cozi[i].inceput=NULL;
   	vector_de_cozi[i].sfarsit=NULL;
   }
   for (i=0;i<s;i++)
   {
   	vector_de_stive[i].vf=NULL;
   }
  

   for(i=0; i < n ; i++)
   {
   	
   	//citi operatia;
   	fscanf(in,"%s",operatie);
   	//in functie de operatia aleasa intram in cazul corespunzator
   	//apeland functiile de mai sus
  
   		if (strcmp(operatie,"intrq") == 0)
   		{
   			PUSH_COADA(&vector_de_cozi,in);
   		

   		}
   		else if(strcmp(operatie,"push") == 0)
   			PUSH_STIVA(&vector_de_stive,in);
   		
   		else if( strcmp(operatie,"pop") == 0)
   		{
   			   			
   			fscanf(in,"%d",&id_stiva);
   			pop_stiva(&vector_de_stive[id_stiva]);
   		}
   		
   		else if(strcmp(operatie,"extrq") == 0)
   		{
			fscanf(in,"%d",&id_coada);
   			pop_coada(&vector_de_cozi[id_coada]);
   		}
   		else if(strcmp(operatie,"sorts") == 0)
   		{
   			fscanf(in,"%d",&id_stiva);
   			sort_stiva(&vector_de_stive[id_stiva]);
   		}
   		else if(strcmp(operatie,"sortq") == 0)
   		{
   			fscanf(in,"%d",&id_coada);
   			sort_coada(&vector_de_cozi[id_coada]);
   		}
   		else if(strcmp(operatie,"corrects") == 0)
   		{
   			fscanf(in,"%d",&id_stiva);
			fprintf(out,"%d\n",corect_stiva(vector_de_stive[id_stiva]));
   			
   			
   		}
   		else if(strcmp(operatie,"correctq") == 0)
   		{
   			fscanf(in,"%d",&id_coada);
   			fprintf(out,"%d\n",corect_coada(vector_de_cozi[id_coada]));
   			//free(aux);
   		}
   		else if(strcmp(operatie,"prints") == 0)
   		{
   			afisare_vector_de_stive(&vector_de_stive,s,out);
   		}
   		else if(strcmp(operatie,"printq") == 0)
   		{		
   			afisare_vector_de_cozi(&vector_de_cozi,c,out);
   		}
   		
   		

   }
   fclose(in);
   fclose(out);
  
}
